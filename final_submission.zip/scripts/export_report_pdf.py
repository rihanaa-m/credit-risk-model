"""Export reports/interim_report.md to a simple PDF."""

from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas


ROOT = Path(__file__).resolve().parents[1]
MD_PATH = ROOT / "reports" / "interim_report.md"
PDF_PATH = ROOT / "reports" / "interim_report.pdf"


def clean_markdown_line(line: str) -> str:
    line = line.rstrip("\n")
    for prefix in ("# ", "## ", "### ", "- ", "* "):
        if line.startswith(prefix):
            line = line[len(prefix) :]
            break
    line = line.replace("**", "").replace("`", "")
    return line


def main() -> None:
    if not MD_PATH.exists():
        raise FileNotFoundError(f"Missing markdown report: {MD_PATH}")

    lines = [clean_markdown_line(ln) for ln in MD_PATH.read_text(encoding="utf-8").splitlines()]

    c = canvas.Canvas(str(PDF_PATH), pagesize=A4)
    width, height = A4
    left = 2 * cm
    top = height - 2 * cm
    bottom = 2 * cm
    line_height = 14

    try:
        pdfmetrics.registerFont(TTFont("DejaVuSans", "DejaVuSans.ttf"))
        c.setFont("DejaVuSans", 10)
    except Exception:
        c.setFont("Helvetica", 10)

    y = top
    for line in lines:
        text = line if line.strip() else " "
        if len(text) > 120:
            chunks = [text[i : i + 120] for i in range(0, len(text), 120)]
        else:
            chunks = [text]

        for chunk in chunks:
            if y < bottom:
                c.showPage()
                c.setFont("Helvetica", 10)
                y = top
            c.drawString(left, y, chunk)
            y -= line_height

    c.save()
    print(f"Wrote {PDF_PATH}")


if __name__ == "__main__":
    main()

