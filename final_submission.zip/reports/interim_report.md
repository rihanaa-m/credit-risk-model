# Interim Report — Credit Risk Probability Model (Week 4)

**Role:** Analytics Engineer, Bati Bank  
**Partner data:** Xente eCommerce transactions (Uganda, UGX)  
**Prepared for:** Interim submission (Tasks 1 & 2)  
**Date:** 2 June 2026

---

## Executive Summary

This interim deliverable establishes the business and analytical foundation for a **buy-now-pay-later (BNPL)** credit scoring product. **Task 1** documents Basel II governance requirements, the need for a proxy default target, and interpretability trade-offs. **Task 2** explores **95,662 transactions** from **3,742 customers** (Nov 2018 – Feb 2019). EDA reveals severe value skew, category-driven fraud variation, and extreme class imbalance (fraud ~0.20%). **All key findings below are supported with labeled figures** (Figures 1–5). Section 4 outlines concrete next steps for WoE/IV feature engineering, RFM proxy labeling, and evaluation metrics.

---

## 1. Business Understanding (Task 1)

### 1.1 Business objective

Bati Bank is partnering with Xente to score BNPL applicants using eCommerce transaction behavior. The model must output a **risk probability** to inform approvals, credit limits, and loan terms under **Basel II** regulatory expectations.

### 1.2 Basel II and interpretability

Basel II requires banks to **measure, document, and govern** credit risk:

- **Explainability** for risk and compliance teams  
- **Auditability** and reproducibility of pipelines and decisions  
- **Ongoing monitoring** with documented limitations  

### 1.3 Proxy target necessity and risks

No direct **default label** exists. A **proxy target** (RFM-based `is_high_risk` in Task 4) is required. Risks: label misalignment, fairness bias against low-activity users, and model drift as the platform evolves.

### 1.4 Model trade-offs

| Approach | Strengths | Regulated-context risk |
|----------|-----------|------------------------|
| Logistic Regression + WoE | Transparent, scorecard-friendly | May underfit nonlinear patterns |
| Gradient Boosting | Higher predictive power | Harder to explain; more governance |

**Recommendation:** WoE + logistic baseline first; adopt boosting only with PR-AUC gains and SHAP documentation.

---

## 2. EDA Findings (Task 2)

### 2.1 Data scope and quality

| Attribute | Finding |
|-----------|---------|
| Records | 95,662 transactions |
| Customers | 3,742 unique `CustomerId` |
| Period | 2018-11-15 → 2019-02-13 |
| Missing values | **0%** in core fields |

### 2.2 Summary statistics

| Statistic | Value (UGX) | Amount (UGX) |
|-----------|-------------|--------------|
| Mean | 9,901 | 6,718 |
| Median | 1,000 | 1,000 |
| Std dev | 123,122 | 123,307 |
| Maximum | 9,880,000 | 9,880,000 |

### 2.3 Visual analysis (embedded in PDF)

| Figure | File | Key takeaway |
|--------|------|--------------|
| **Figure 1** | `value_distribution.png` | Strong right skew; use robust aggregates |
| **Figure 2** | `fraud_rate_by_category.png` | Fraud varies by category (transport highest) |
| **Figure 3** | `daily_transaction_volume.png` | Stable daily volume; supports temporal features |
| **Figure 4** | `correlation_heatmap.png` | Weak linear fraud correlation; need engineered features |
| **Figure 5** | `outlier_boxplots.png` | Long tails; winsorize and handle credits separately |

![Figure 1 — Value distribution](../analysis_outputs/task2/value_distribution.png)

![Figure 2 — Fraud rate by category](../analysis_outputs/task2/fraud_rate_by_category.png)

![Figure 3 — Daily transaction volume](../analysis_outputs/task2/daily_transaction_volume.png)

![Figure 4 — Correlation heatmap](../analysis_outputs/task2/correlation_heatmap.png)

![Figure 5 — Outlier box plots](../analysis_outputs/task2/outlier_boxplots.png)

### 2.4 Fraud and category patterns

| FraudResult | Rate |
|-------------|------|
| Legitimate (0) | 99.80% |
| Fraud (1) | 0.20% |

| ProductCategory | Fraud rate | n |
|-----------------|------------|---|
| transport | 8.00% | 25 |
| utility_bill | 0.63% | 1,920 |
| financial_services | 0.35% | 45,405 |
| airtime | 0.04% | 45,027 |

### 2.5 Top 5 EDA insights

1. **Severe imbalance (~0.2%)** — prioritize PR-AUC, F1, recall; use class weights.  
2. **Heavy skew/outliers** — winsorize at 99th pct; log1p on customer aggregates.  
3. **Category-driven risk** — encode `ProductCategory`; validate minority segments.  
4. **Dominant categories** — airtime + financial_services = ~95% of rows.  
5. **Customer-level modeling** — features and RFM per `CustomerId`.

---

## 3. Next Steps (Tasks 3–6) — Detailed Plan

### 3.1 Task 3 — Feature engineering (`sklearn.pipeline.Pipeline`)

| Step | Technique |
|------|-----------|
| Aggregates | sum/mean/count/std of Amount & Value per customer |
| Time features | hour, day, month, year; recency days |
| Encoding | one-hot or label encoding for categoricals |
| Missing values | median/mode imputation |
| Scaling | `StandardScaler` |
| **WoE / IV** | bin continuous vars; compute **Weight of Evidence** per bin; rank by **Information Value** (IV > 0.3 = strong predictor); apply WoE transform for scorecard |

### 3.2 Task 4 — Proxy target (RFM)

| Metric | Definition |
|--------|------------|
| Recency | Days since last transaction (snapshot = max date) |
| Frequency | Transaction count per customer |
| Monetary | Sum of transaction values |
| Clustering | K-Means (k=3), scaled RFM, `random_state=42` |
| Label | `is_high_risk = 1` for least engaged cluster |

### 3.3 Task 5 — Modeling and metrics

**Models:** Logistic Regression (WoE), Random Forest, XGBoost/LightGBM  
**Tuning:** GridSearchCV / RandomizedSearchCV  
**Tracking:** MLflow (params, metrics, artifacts)

| Metric | Use case |
|--------|----------|
| Accuracy | Secondary (misleading with imbalance) |
| Precision | Cost of false approvals |
| Recall | Capture high-risk customers |
| F1 | Balance precision/recall |
| ROC-AUC | Ranking across thresholds |
| **PR-AUC** | **Primary metric for rare positive class** |

**Selection criterion:** best model by **PR-AUC** on stratified 80/20 hold-out (`random_state=42`).

### 3.4 Task 6 — Deployment

FastAPI `/predict`, Docker, GitHub Actions CI (flake8 + pytest).

---

## 4. Limitations

- Fraud label ≠ credit default; proxy remains an explicit assumption.  
- Short window (~3 months); limited seasonality.  
- Single country/currency (Uganda / UGX).

---

*Regenerate PDF: `python scripts/run_task2_eda.py` then `python scripts/generate_interim_report_pdf.py`*  
*Output: `reports/interim_report_revised.pdf` (close any open PDF first to overwrite `interim_report.pdf`)*
